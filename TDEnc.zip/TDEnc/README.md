# つんでれんこ

[![Gitter](https://badges.gitter.im/TDEnc/Lobby.svg)](https://gitter.im/TDEnc/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Read 読んでください.txt.
